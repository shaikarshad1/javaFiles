package Trees;

import java.util.Scanner;

public class BST {

    private BinaryTree.Node root;
    class Node{
        private int value;
        private BinaryTree.Node left;
        private BinaryTree.Node right;

        public Node(int value) {
            this.value = value;
        }
    }

//    void insertroot(int val){
//        root.
//    }
}
