package abstra;

public class Child extends Parent {

     void m1(){

     }
}
