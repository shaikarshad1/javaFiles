package abstra;

public abstract class Parent {

    public static void mi(){
        System.out.println("in parent class");
    }
    abstract void m1();
}
