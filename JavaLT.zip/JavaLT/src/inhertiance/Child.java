package inhertiance;

public class Child extends Parent{

    public static void mi(){
        System.out.println("in child class");
    }
}
