package inhertiance;

public class Main {
    public static void main(String[] args) {
        Child.mi();
        Parent.mi();
    }
}
