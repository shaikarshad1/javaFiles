package inhertiance;

public class Parent {

    public static void mi(){
        System.out.println("in parent class");
    }
}
