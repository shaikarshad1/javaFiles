package linkedList;

public class DoubleLLV2 {

    private Node head;

    public class Node{
        int val;
        Node prev;
        Node next;
    }
}
