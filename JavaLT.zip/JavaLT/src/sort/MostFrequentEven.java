package sort;

import java.util.ArrayList;
import java.util.List;

public class MostFrequentEven {
    public static void main(String[] args) {
        int[] n={0,1,2,2,4,4,1};int max=n[0],i=0;
        for( i=1;i<n.length;i++){
            if(n[i]>max){
                max=n[i];
            }
        }

//        List<Integer> re=new ArrayList<>();
        int[] co=new int[max+1];
        i=0;max=0;
        while(i<n.length){

        }
    }
}
